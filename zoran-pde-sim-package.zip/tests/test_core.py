from zpdesim.core import ZoranPDESim

def test_step():
    sim = ZoranPDESim(10, 10)
    field_before = sim.field.copy()
    field_after = sim.step(0.5)
    assert (field_after - field_before).all() == 0.5 or (field_after - field_before).all() > 0
