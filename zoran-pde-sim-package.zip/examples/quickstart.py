from zpdesim.core import ZoranPDESim

sim = ZoranPDESim(10, 10)
print("Initial:", sim.field)
print("After step:", sim.step(0.5))
