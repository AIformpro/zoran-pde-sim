import numpy as np

class ZoranPDESim:
    def __init__(self, nx=100, ny=100):
        self.nx, self.ny = nx, ny
        self.field = np.zeros((nx, ny))
    def step(self, dt=0.1):
        self.field += dt
        return self.field
